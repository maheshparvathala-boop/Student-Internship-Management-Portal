package com.example.demo.service;
import org.springframework.stereotype.Service;
import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;
@Service
public class UserService {
 private final UserRepository repo;
 public UserService(UserRepository r){this.repo=r;}
 public User register(User u){return repo.save(u);}
 public User login(String email,String pass){
   User u=repo.findByEmail(email);
   if(u!=null && u.getPassword().equals(pass)) return u;
   return null;
 }
}
