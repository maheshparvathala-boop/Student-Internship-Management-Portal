package com.example.demo.controller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.example.demo.entity.User;
import com.example.demo.service.UserService;

@Controller
public class HomeController {
 private final UserService service;
 public HomeController(UserService s){this.service=s;}

 @GetMapping("/")
 public String home(){ return "index";}

 @GetMapping("/register")
 public String registerPage(){ return "register"; }

 @PostMapping("/register")
 public String register(@ModelAttribute User u, Model m){
   service.register(u);
   m.addAttribute("msg","Registered!");
   return "index";
 }

 @PostMapping("/login")
 public String login(@RequestParam String email, @RequestParam String password, Model m){
   User u=service.login(email,password);
   if(u==null){
     m.addAttribute("error","Invalid login");
     return "index";
   }
   m.addAttribute("user",u);
   return "dashboard";
 }
}
