# Student Login & Profile Management System

Full-stack Java project (Spring Boot backend + React + Vite frontend).

## Structure
- backend/  (Spring Boot application)
- frontend/ (React + Vite application)
- README.md
- postman_collection.json

## How to run

### Backend
1. Ensure Java 17 and Maven are installed.
2. Edit `backend/src/main/resources/application.properties` for your MySQL config (or use H2 in-memory).
3. From backend folder:
   ```
   mvn spring-boot:run
   ```
   or build:
   ```
   mvn package
   java -jar target/backend-0.0.1-SNAPSHOT.jar
   ```

### Frontend
1. Ensure Node.js 18+ and npm/yarn installed.
2. From frontend folder:
   ```
   npm install
   npm run dev
   ```

The backend exposes APIs under `http://localhost:8080/api/student`.
