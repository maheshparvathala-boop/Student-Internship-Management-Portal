import React, {useState} from 'react';
import Register from './components/Register';
import Login from './components/Login';
import Profile from './components/Profile';

export default function App(){
  const [user, setUser] = useState(null);

  return (
    <div style={{padding:20,fontFamily:'Arial'}}>
      <h1>Student App</h1>
      {!user && <>
        <Register />
        <hr/>
        <Login onLogin={setUser} />
      </>}
      {user && <Profile user={user} />}
    </div>
  );
}
