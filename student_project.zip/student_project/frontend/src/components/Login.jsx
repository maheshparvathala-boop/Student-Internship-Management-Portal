import React, {useState} from 'react';
import axios from 'axios';

export default function Login({onLogin}){
  const [form,setForm] = useState({email:'',password:''});

  const submit = async () => {
    try {
      const res = await axios.post('http://localhost:8080/api/student/login', form);
      onLogin(res.data);
    } catch(err){ alert(err.response?.data || err.message); }
  };

  return (
    <div>
      <h2>Login</h2>
      <input placeholder='Email' onChange={e=>setForm({...form,email:e.target.value})} /><br/>
      <input placeholder='Password' type='password' onChange={e=>setForm({...form,password:e.target.value})} /><br/>
      <button onClick={submit}>Login</button>
    </div>
  );
}
