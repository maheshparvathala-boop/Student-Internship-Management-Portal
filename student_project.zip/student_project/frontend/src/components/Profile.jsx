import React from 'react';

export default function Profile({user}){
  return (
    <div>
      <h2>Profile</h2>
      <p><strong>ID:</strong> {user.id}</p>
      <p><strong>Name:</strong> {user.name}</p>
      <p><strong>Email:</strong> {user.email}</p>
      <p><strong>Course:</strong> {user.course}</p>
    </div>
  );
}
