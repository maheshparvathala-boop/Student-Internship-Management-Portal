import React, {useState} from 'react';
import axios from 'axios';

export default function Register(){
  const [form,setForm] = useState({name:'',email:'',password:'',course:''});

  const submit = async () => {
    try {
      await axios.post('http://localhost:8080/api/student/register', form);
      alert('Registered successfully');
    } catch(err){ alert(err.response?.data || err.message); }
  };

  return (
    <div>
      <h2>Register</h2>
      <input placeholder='Name' onChange={e=>setForm({...form,name:e.target.value})} /><br/>
      <input placeholder='Email' onChange={e=>setForm({...form,email:e.target.value})} /><br/>
      <input placeholder='Password' type='password' onChange={e=>setForm({...form,password:e.target.value})} /><br/>
      <input placeholder='Course' onChange={e=>setForm({...form,course:e.target.value})} /><br/>
      <button onClick={submit}>Register</button>
    </div>
  );
}
