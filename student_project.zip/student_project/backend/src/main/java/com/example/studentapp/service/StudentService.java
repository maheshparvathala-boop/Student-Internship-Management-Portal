package com.example.studentapp.service;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.studentapp.model.Student;
import com.example.studentapp.repository.StudentRepository;

@Service
public class StudentService {

    @Autowired
    private StudentRepository repo;

    public Student register(Student s){
        return repo.save(s);
    }

    public Optional<Student> login(String email, String password){
        return repo.findByEmail(email).filter(u -> u.getPassword().equals(password));
    }

    public Optional<Student> getProfile(Long id){
        return repo.findById(id);
    }
}
